@echo off
rem Awesome Tanks 2.0 — запуск в один клик (нужен установленный Python 3)
where py >nul 2>nul && (py -3 start.py %* & goto :eof)
python start.py %*
